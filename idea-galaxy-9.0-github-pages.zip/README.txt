Idea Galaxy 9.0 - GitHub Pages 公開用

1. GitHub で Public リポジトリ idea-galaxy を作成
2. このフォルダ内の index.html をリポジトリの最上位にアップロード
3. Settings > Pages > Deploy from a branch > main > /(root) > Save
4. 数分待って https://ユーザー名.github.io/idea-galaxy/ にアクセス

注意: 3D表示にはインターネット接続が必要です。APIキーを公開しないでください。
